import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.CallableStatement;
import java.sql.DriverManager;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/YourServletURL")
public class YourServletName extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form data
        String param1 = request.getParameter("param1");

        // JDBC Connection and stored procedure call
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce", "root", "Anu@#1234567");
             CallableStatement callableStatement = connection.prepareCall("{call YourStoredProcedureName(?, ?)}")) {

            callableStatement.setString(1, param1);
            callableStatement.registerOutParameter(2, java.sql.Types.DATE); // Set the correct data type

            callableStatement.execute();

            // Retrieve the output parameter if needed
            String param2 = callableStatement.getString(2);

            // Process the result if needed

            // Send response
            PrintWriter out = response.getWriter();
            out.println("Stored procedure executed successfully.");
        } catch (SQLException e) {
            // Handle exceptions
            e.printStackTrace();
        }
    }
}